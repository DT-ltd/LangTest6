How to translate DipTrace Interface to your native language:
_____________________________

Use the following files from "C:\ProgramData\DipTrace\Data" (Windows Vista,7) or 
"C:\Documents and Settings\All Users\Application Data\DipTrace\Data" (XP):
diptrace.lng, schematic.lng, pattedit.lng and compedit.lng - these are
interface files for PCB Layout, Schematic, Pattern Editor and
Component Editor, which contain all menu items, messages, etc.
Notice to view data folder you should display hidden folders in Windows folder properties.


Use the attached program (lng.exe) to open .lng files ("Open Source"
button), then use "Select Form" to select the list (all lists should
be translated) - "Form" items correspond to program windows/dialog boxes, 
"Messages" item - messages and parts of messages. To save translated file use 
"Save Translated", to open translated file and continue translation select 
"Open Translated". Notice primary structure of interface file is made 
from source file, so you should open source file before translated file.

To check the correctness of translation insert translated diptrace.lng,
schematic.lng, pattedit.lng and compedit.lng to Data folder (see above), 
than run package programs one-by-one.

If you would like to search for empty (non-translated) items, keep the string 
blank and click Search. If you enter something there - it searches for both original 
and translated strings.

If you have any questions or suggestions, please contact us at: support@diptrace.com.
_____________________________

Notice: Anyone can use these instructions to translate the program
interface to his native language or update existing interface if the 
version on our web-site is outdated, and get free registration of
Full Edition.

If you are interested, please let us know you are translating the interface 
to your language (specify the language) and to ensure your language 
is not already taken.

The list of existing and "coming soon" (taken) languages are placed at 
http://www.diptrace.com/language.php